import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class CrossGameTest {


	CrossGame cgTest =  new CrossGame();

	@Test
	public void testConstructor() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				assertEquals(cgTest.getSquareValue(i, j), 0);
			}
		}
		assertEquals(cgTest.getPlayer(), false);
	}
	
	@Test
	private void testRowNCol() {
		assertEquals(cgTest.getCol(), 7);
		assertEquals(cgTest.getRow(), 6);
	}
	

	@Test
	private void testSet() {
		boolean bol = false;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				assertEquals(cgTest.getPlayer(), bol);
				cgTest.set(i, j);
				if (!bol) {
					assertEquals(cgTest.getSquareValue(i, j), 1);
					bol = true;
				}
				else {
					assertEquals(cgTest.getSquareValue(i, j), 2);
					bol = false;
				}
			}
		}
	}

	

}

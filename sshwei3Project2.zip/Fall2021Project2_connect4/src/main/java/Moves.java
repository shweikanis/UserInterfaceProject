public class Moves {
	private int x;
	private int y;
	private boolean p;
	
	public Moves (int i, int j, boolean k) {
		x = i; 
		y = j;
		p = k;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean getP() {
		return p;
	}
}	
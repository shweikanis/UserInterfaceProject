

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class JavaFXTemplate extends Application {

	// DisableButtons
	// disables all of the buttons of the matrix
	private void DisableButtons(Button[][] b, int r, int c) {
		for (int i = 0; i < r; i++) 
			for (int j = 0; j < c; j++) 
				b[i][j].setDisable(true);
	}
	
	// NewGame function
	// start a new game by creating a new scene and calling the gamesene function
	private void NewGame(Stage primaryStage) {
		Scene newGame = new Scene(GameScene(primaryStage), 1000, 500);
		primaryStage.setScene(newGame);
		primaryStage.show();
	}

	// DisplayWinner function
	// Display the winner or tie for the results of the game
	private void DisplayWinner(Stage primaryStage, int winner) {

		// create VBox for the scene
		VBox finale = new VBox();

		// initialize again button
		// call function new game when button on action
		Button again = new Button("Play again");
		again.setTranslateX(100);
		again.setTranslateY(100);
		again.setPrefSize(100, 20);
		again.setOnAction(e->NewGame(primaryStage));

		// initialize exit button and exit the progam when button set on action
		Button exit = new Button("Exit");
		exit.setTranslateX(100);
		exit.setTranslateY(105);
		exit.setPrefSize(100, 20);
		exit.setOnAction(e->{Platform.exit(); System.exit(0);});

		// initialize label to display the results
		Label TheWinner = new Label();
		if (winner == 0) TheWinner.setText("Tie!");
		else TheWinner.setText("The winner is Player " + winner + "!");
		TheWinner.setTranslateX(90);
		TheWinner.setTranslateY(20);

		// add all components to the VBox
		finale.getChildren().addAll(again, exit, TheWinner);

		// set the scene of the VBox and show the scene
        Scene WinnerScene = new Scene(finale, 300, 250);
        primaryStage.setScene(WinnerScene);
        primaryStage.show();
	}
	
	// Display constructions of how to play
	private void HowToPlay() {
        Label secondLabel = new Label("Connect four to win the game.\n You have to make a row of four checkers of the same color.\n "
        		+ "The rows can be done vertically, horizontally or diagonally.");
        
        VBox secondaryLayout = new VBox();
        secondaryLayout.getChildren().add(secondLabel);
        
        Scene secondScene = new Scene(secondaryLayout, 350, 100);
        
        Stage secondStage = new Stage();
        secondStage.setTitle("How to play");
        secondStage.setScene(secondScene);
        
        secondStage.show();
	}
	
	// ConnectFourGP Function
	// returns the grid pane of the game's matrix and results
	private GridPane ConectFourGP(MenuItem r, Stage primaryStage, MenuItem t1, MenuItem t2, MenuItem t3) {
		// initialize pause duration
		PauseTransition pause = new PauseTransition(Duration.seconds(2)); // initialize a new pause transition and set the amount of time to pause

		// create game class and get the dimensions
		CrossGame cg = new CrossGame();
		int R = cg.getRow();
		int C = cg.getCol();

		// create the grid pane with the buttons matrix
		GridPane gp = new GridPane();
		Button[][] b = new Button[R][C];

		// update themes
		t1.setOnAction(e-> gp.setStyle("-fx-background-image: url()"));
		t2.setOnAction(e-> gp.setStyle("-fx-background-image: url(toystroy.jpg)"));
		t3.setOnAction(e-> gp.setStyle("-fx-background-image: url(halloween.jpg)"));

		// set grid pane alignments and gaps
		gp.setPadding(new Insets(10));
		gp.setAlignment(Pos.CENTER);
		gp.setHgap(5);
		gp.setVgap(5);

		// create and add labels to display the assist the players
		Label turn= new Label("Turn: Player 1"); 
		Label movement= new Label();
		gp.add(turn, 9, 0);
		gp.add(movement, 9, 2);

		// loop to create the buttons matrix
		for (int i = 0; i < R; i++) {
			for (int j = 0; j < C; j++) {

				// initialize color and size
				b[i][j] = new Button();
				b[i][j].setStyle("-fx-background-color: darkgray ");
				b[i][j].setPrefSize(50, 50);

				// create final copies of the x and y positions
				final int icopy = i;
				final int jcopy = j;

				// set each button on action
				b[i][j].setOnAction(new EventHandler<ActionEvent>(){
					public void handle(ActionEvent action){

						// Call set function to know the result
						// display the color that matches the player
						// display the result for winner or tie
						int result = cg.set(icopy,  jcopy);
						if (result == 1) {
							b[icopy][jcopy].setStyle ("-fx-background-color: darksalmon ");
							movement.setTextFill(Color.DARKRED);
							movement.setText("Player 1 moved " +icopy + "," + jcopy);
							turn.setText("Turn: Player 2");
						}
						else if (result == 2) {
							b[icopy][jcopy].setStyle("-fx-background-color: lightblue ");
							movement.setTextFill(Color.BLUE);
							movement.setText("Player 2 moved " +icopy + "," + jcopy);
							turn.setText("Turn: Player 1");
						}
						else {
							movement.setTextFill(Color.BLACK);
							movement.setText("Invalid movement");
						}

						// display results if winner of tie found
						int connected[][] = cg.FindSeq();
						if ( connected[0][0] != 0) {
							DisableButtons(b, R, C);  // call function to disable buttons
							for (int l = 1; l < 5; l++)  // change seq buttons to gold
								b[connected[l][0]][connected[l][1]].setStyle("-fx-background-color: gold ");
							movement.setTextFill(Color.GOLD);
							movement.setText("Player " + connected[0][0] + " Won!");
							pause.play(); // starts the pause
							pause.setOnFinished(e -> DisplayWinner(primaryStage, connected[0][0]));  // call function to display results
						}
						else if (cg.Tie() == 0) {
							DisableButtons(b, R, C);  // call function to disable buttons
							movement.setTextFill(Color.BLACK);
							movement.setText("Tie!");
							pause.play(); // starts the pause
							pause.setOnFinished(e -> DisplayWinner(primaryStage, 0));  // call function to display results
						}
					}
				});

				gp.add(b[i][j], j, i);  // add button to the grid pane
			}
		}

		// reverse moves when Reverse menuItem is pressed
		// update the button matrix and the player's turn
		r.setOnAction(e-> {
			Moves mv = cg.Reverse();
			b[mv.getX()][mv.getY()].setStyle("-fx-background-color: #A9A9A9; ");
			movement.setTextFill(Color.BLACK);
			movement.setText("Reverse");
			if (mv.getP()) turn.setText("Turn: player 1");
			else turn.setText("Turn: player 2");
			});

		return gp;
	}
	
	// GameScene function
	// returns a border pane for a new game
	private BorderPane GameScene(Stage primaryStage) {

		// initialize menus and menu items
		Menu gp = new Menu("Game play");
		Menu themes = new Menu("Themes");
		Menu options = new Menu("Options");
		
		MenuItem gpReverse = new MenuItem("Reverse");
		MenuItem theme0 = new MenuItem("Original Theme");
		MenuItem theme1 = new MenuItem("Theme One");
		MenuItem theme2 = new MenuItem("Theme Two");
		MenuItem option0 = new MenuItem("How to play");
		MenuItem option1 = new MenuItem("New game");
		MenuItem option2 = new MenuItem("Exit");

		option2.setOnAction(e->{Platform.exit(); System.exit(0);});  // set on action exit menu item to exit the program

		// set on action option 0 menu item
		// Call how to play function
		option0.setOnAction(e->HowToPlay());
		
		option1.setOnAction(e->NewGame(primaryStage));  // start new game when option1 on action

		// Add menu items to the menus
		gp.getItems().add(gpReverse);
		themes.getItems().addAll(theme0, theme1, theme2);
		options.getItems().addAll(option0, option1, option2);
		
		// create menu bar and add the menus
		MenuBar mb = new MenuBar();
		mb.getMenus().addAll(gp, themes, options);
		
		// call function to create the grid pane
		GridPane connect4 = ConectFourGP(gpReverse, primaryStage, theme0, theme1, theme2);
		
		// create the border pane and add components
		BorderPane bp = new BorderPane();
		bp.setTop(mb);
		bp.setCenter(connect4);

		return bp;  // return the border pane
	}


	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Welcome to Connect Four!");

		// initialize start button
		// set scene to the game scene on action
		Button start = new Button("Start");
		start.setTranslateX(130);
		start.setTranslateY(100);
		start.setPrefSize(50, 20);
		start.setOnAction(e->NewGame(primaryStage));

		// initialize exit button
		// exit the program on action
		Button exit = new Button("Exit");
		exit.setTranslateX(130);
		exit.setTranslateY(105);
		exit.setPrefSize(50, 20);
		exit.setOnAction(e->{Platform.exit(); System.exit(0);});

		// initialize the label to welcome to the game
		Label welcome = new Label("Welcome to the game!");
		welcome.setTranslateX(90);
		welcome.setTranslateY(50);

		// initialize VBox  and add components
		VBox welcomeWindow = new VBox();
		welcomeWindow.getChildren().addAll(welcome, start, exit);

		// welecome to the game scene
		Scene welcomeScene = new Scene(welcomeWindow, 300,250);
		
		// set scene to the stage and show
		primaryStage.setScene(welcomeScene);
		primaryStage.show();
	}
	
}

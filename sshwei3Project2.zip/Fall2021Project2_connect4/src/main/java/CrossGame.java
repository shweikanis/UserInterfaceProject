import java.util.Stack;

public class CrossGame {

	private boolean player;
	private int[][] board;
	private static int ROW = 6;
	private static int COL = 7;
	
	private Stack<Moves> rStack;

	public CrossGame() {
		player = false;  // initialize false for player 1. true for player 2
		rStack = new Stack<>();  // initialize the stack for the reverse

		// initialize matrix values to 0
		// value 1 for player 1
		// value for player 2
		board = new int[ROW][COL];
		for (int i = 0; i < ROW; i++) {
			for (int j = 0; j < COL; j++) {
				board[i][j] = 0;
			}
		}
	}
	
	// getters for number of columns and rows
	public int getRow() {
		return ROW;
	}
	public int getCol() {
		return COL;
	}

	// setting new movement
	public int set(int i, int j) {
		if (board[i][j] != 0) return 0;  // return 0 if block occupied

		// initialize move instance and push to stack
		Moves move = new Moves(i, j, player);
		rStack.push(move);

		// update matrix value
		// update the player's turn
		// return the value of the player who did the play
		if (valid(i, j)) {
			if (!player) {
				board[i][j] = 1;
				player = true;
				return 1;
			}
			else {
				board[i][j] = 2;
				player = false;
				return 2;
			}
		}

		else return 0;  // return 0 if the movement is invalid
	}

	// valid function
	// returns 1 if it was the first row
	// or if the lower row is filled
	// else return false
	private boolean valid(int row, int col) {
		if (row == 5) return true;
		if (board[row+1][col] != 0) return true;
		return false;
	}

	// Reverse function
	// pops the last move and updates the matrix
	// return the move instance to update the buttons
	public Moves Reverse() {
		//if (rStack.empty()) return null;
		Moves move = rStack.pop();
		board[move.getX()][move.getY()] = 0;
		player = move.getP();
		return move;
	}
 
	// findsequence function
	// returns the player who won and the sequence they created
	// else returns 0 as first index of the 2d array
	public int[][] FindSeq() {
		int[][] seq = new int[5][2];
		// find horizontal sequence
		for (int i = ROW-1; i >= 0; i--) {
			for (int j = 0; j < 4; j++)
				if (board[i][j] != 0 && board[i][j] == board[i][1+j] && board[i][j] == board[i][2+j] && board[i][j] == board[i][3+j]) {
					seq[0][0] = board[i][j];
					seq[1][0] = i;
					seq[1][1] = j;
					seq[2][0] = i;
					seq[2][1] = j+1;
					seq[3][0] = i;
					seq[3][1] = j+2;
					seq[4][0] = i;
					seq[4][1] = j+3;
					return seq;
				}
		}
		// find vertical sequence
		for (int i = 0; i < COL; i++) {
			for (int j = 0; j < 3; j++) 
				if (board[j][i] != 0 && board[j][i] == board[j+1][i] && board[j][i] == board[j+2][i] && board[j][i] == board[j+3][i]) {
					seq[0][0] = board[j][i];
					seq[1][0] = j;
					seq[1][1] = i;
					seq[2][0] = j+1;
					seq[2][1] = i;
					seq[3][0] = j+2;
					seq[3][1] = i;
					seq[4][0] = j+3;
					seq[4][1] = i;
					return seq;
				}
		}
		// find diagonal sequence
		for (int i = 0; i < 3; i++) {
			for (int j = 3; j < COL; j++)  // down left to up right
				if (board[i][j] != 0 && board[i][j] == board[i+1][j-1] && board[i][j] == board[i+2][j-2] && board[i][j] == board[i+3][j-3]) {
					seq[0][0] = board[i][j];
					seq[1][0] = i;
					seq[1][1] = j;
					seq[2][0] = i+1;
					seq[2][1] = j-1;
					seq[3][0] = i+2;
					seq[3][1] = j-2;
					seq[4][0] = i+3;
					seq[4][1] = j-3;
					return seq;
				}

			for (int k = 3; k >= 0; k--)  // up left to down right
				if (board[i][k] != 0 && board[i][k] == board[i+1][k+1] && board[i][k] == board[i+2][k+2] && board[i][k] == board[i+3][k+3]) {
					seq[0][0] = board[i][k];
					seq[1][0] = i;
					seq[1][1] = k;
					seq[2][0] = i+1;
					seq[2][1] = k+1;
					seq[3][0] = i+2;
					seq[3][1] = k+2;
					seq[4][0] = i+3;
					seq[4][1] = k+3;
					return seq;
				}
		}
		
		seq[0][0] = 0;
		return seq;
	}
	
	// Tie function
	// Return 0 if the highest row is all filled
	public int Tie() {
		for (int i = 0; i < 6; i++)  // check if all highest row is filled
			if (board[0][i] == 0)  return 1;
		return 0;
	}
	
	// functions for testing
	
	public int getSquareValue(int x, int y) {
		return board[x][y];
	}
	public boolean getPlayer() {
		return player;
	}
}

import java.util.Arrays;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class PuzzleGUI {
	private Label[] puzzleArr;
	private GridPane GPdisplay;
	//private int[][] collection;
	private int[] example = {2, 6, 10, 3, 1, 4, 7, 11, 8, 5, 9, 15, 12, 13, 14, 0};
	private int[] solution = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
	final private int SIZE = 16;
	Node n;
	
	PuzzleGUI() {
		GPdisplay = new GridPane();
		GPdisplay.setPadding(new Insets(10, 10, 10, 10));
		GPdisplay.setVgap(5);
		GPdisplay.setHgap(5);
		GPdisplay.setAlignment(Pos.CENTER);

		n = new Node(example);

		puzzleArr = new Label[SIZE];
		for (int i = 0; i < SIZE; i++)
			puzzleArr[i] = new Label();
		
		int cnt = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				GPdisplay.add(puzzleArr[cnt], j, i);
				cnt++;
			}
		}

		SetPuzzle(n.getKey());
	}
	
	public GridPane GetGP() {
		return GPdisplay;
	}

	public Node GetNode() {
		return n;
	}

	private void SetPuzzle(int[] newArr) {
		for (int i = 0; i < SIZE; i++) {
			String iText = newArr[i] + "";
			puzzleArr[i].setText(iText);
		}		
	}
	
	public boolean RightB(){
		int[] rightArray = copyArray(n.getKey());	//make copy of puzzleArray
		
		int zeroIndex = findZero(rightArray);		//find index with zero value
		
		if(zeroIndex == 3 || zeroIndex == 7 || zeroIndex == 11 || zeroIndex == 15)	//if index is in this column,can't move right, return
			return false;
		
		moveZero(rightArray, zeroIndex, (zeroIndex+1));		//move the zero one space to the right
		
		//Node newN = new Node(rightArray);
		//newN.setParent(n);
		//n = newN;
		SetPuzzle(rightArray);
		n = new Node(rightArray);

		if (goalTest(rightArray)) return true;
		else return false;
	}
	
	public boolean LeftB(){
		
		int[] leftArray = copyArray(n.getKey());
		
		int zeroIndex = findZero(leftArray);
		
		if(zeroIndex == 0 || zeroIndex == 4 || zeroIndex == 8 || zeroIndex == 12)
			return false;
		
		moveZero(leftArray, zeroIndex, (zeroIndex-1));		//move the zero one space to the left
		SetPuzzle(leftArray);
		n = new Node(leftArray);

		if (goalTest(leftArray)) return true;
		else return false;
		}

	/**
	 * same as above only up
	 * @param puzzleArray
	 * @return true or false
	 */
	public boolean UpB(){
		
		int[] upArray = copyArray(n.getKey());
		
		int zeroIndex = findZero(upArray);
		
		if(zeroIndex == 0 || zeroIndex == 1 || zeroIndex == 2 || zeroIndex == 3)
			return false;
		
		moveZero(upArray, zeroIndex, (zeroIndex-4));		//move the zero one space up
		SetPuzzle(upArray);
		n = new Node(upArray);

		if (goalTest(upArray)) return true;
		else return false;
	}
	
	/**
	 * Same as above, only down
	 * @param puzzleArray
	 * @return true or false
	 */
	public boolean DownB(){
		
		int[] downArray = copyArray(n.getKey());
		
		int zeroIndex = findZero(downArray);
		
		if(zeroIndex == 12 || zeroIndex == 13 || zeroIndex == 14 || zeroIndex == 15)
			return false;
		
		moveZero(downArray, zeroIndex, (zeroIndex+4));		//move the zero one space down
		SetPuzzle(downArray);
		n = new Node(downArray);

		if (goalTest(downArray)) return true;
		else return false;
	}
	
	public int[] copyArray(int[] puzzleArray){
		
		int[] copy = new int[puzzleArray.length];
		
		for(int i= 0; i<copy.length; i++)
			copy[i] = puzzleArray[i];
		
		return copy;
	}
	
	public int findZero(int[] puzzleArray){
		
		for(int i=0; i<puzzleArray.length; i++)
		{
			if(puzzleArray[i] == 0)
				return i;
		}
		
		return -1;
	}
	
	public void moveZero(int[] puzzleArray, int zeroIndex, int moveToIndex){
		
		int temp = puzzleArray[moveToIndex];
		puzzleArray[zeroIndex] = temp;
		puzzleArray[moveToIndex] = 0;
	}

	public boolean goalTest(int[] puzzleArray){
		
		if(Arrays.equals(puzzleArray, solution))
			return true;
		else
			return false;
	}
	
}

import java.util.ArrayList;

import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to JavaFX");
		BorderPane SceneBP = new BorderPane();
		BorderPane ButtonsBP = new BorderPane();

		PuzzleGUI newGame = new PuzzleGUI();
		GridPane gameGP = newGame.GetGP();
		gameGP.setMaxSize(100, 100);

		Button startNew = new Button("New Game");
		Button h1 = new Button("Heoristic 1");
		Button h2 = new Button("Heoristic 2");
		Button sol = new Button("See solution");
		Button exit = new Button("Exit");
		
		//ArrayList<Node> AIsol;
		Thread h1Thread = new Thread(()-> {
			A_IDS_A_15solver ids = new A_IDS_A_15solver(newGame.GetNode(), "heuristicOne");
			//AIsol = ids.GetSolPath();
		});
		h1.setOnAction(e-> {
			h1Thread.start();
			
		});
		
		Thread h2Thread = new Thread(()-> {
			A_IDS_A_15solver ids = new A_IDS_A_15solver(newGame.GetNode(), "heuristicTwo");
			//AIsol = ids.GetSolPath();
		});
		h1.setOnAction(e-> {
			h2Thread.start();
		});
		
		sol.setDisable(true);
		HBox buttonsBox = new HBox();
		buttonsBox.getChildren().addAll(startNew, h1, h2, sol, exit);

		Button right = new Button(">");
		Button left = new Button("<");
		Button up = new Button("^");
		Button down = new Button("v");
		right.setOnAction(e->newGame.RightB());
		left.setOnAction(e->newGame.LeftB());
		up.setOnAction(e->newGame.UpB());
		down.setOnAction(e->newGame.DownB());

		ButtonsBP.setRight(right);
		ButtonsBP.setLeft(left);
		ButtonsBP.setBottom(down);
		ButtonsBP.setTop(up);
		ButtonsBP.setMaxSize(100, 100);

		SceneBP.setLeft(ButtonsBP);
		SceneBP.setTop(buttonsBox);
		SceneBP.setCenter(gameGP);

		Scene scene = new Scene(SceneBP, 700,700);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		//Thread t = new Thread(()-> {A_IDS_A_15solver ids = new A_IDS_A_15solver();});
		//t.start();

	}

}

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class Client extends Thread {
	
	int port;
	String IP;
	Socket socketClient;
	ObjectInputStream in;
	ObjectOutputStream out;
	private Consumer<Serializable> callback;
	Bid bid = new Bid();	//initial bid sent to server
	
	
	Client(Consumer<Serializable> call, int port, String IP) {
		
		callback = call;
		this.port = port;
		this.IP = IP;
		
	}
	
	
	public void run() {
		try {
			socketClient= new Socket(IP, port);
		    out = new ObjectOutputStream(socketClient.getOutputStream());
		    in = new ObjectInputStream(socketClient.getInputStream());
		    socketClient.setTcpNoDelay(true);
			}
			catch(Exception e) {}
		
		while(true) {
			
			// while player is still playing
			// send bid and on who
			// receive player and bankers hand
			// extra draws
			// results
			
			
			
			
		}
		
	} //end of run
	
	
	public void sendBid() {
		try {
			out.writeObject(bid);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}

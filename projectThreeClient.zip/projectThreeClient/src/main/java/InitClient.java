import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.paint.Color;

public class InitClient extends Application {

	private Scene start;
	private Scene gameScene;
	private int serverPort;
	private String serverIP;
	private Client player;
	private Stage primaryStage;

	
	public static void main(String[] args) {
		
		launch(args);
	}
	
	
	public void start(Stage primaryStage) throws Exception {
		
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Baccarat");
		createStartScreen();
		this.primaryStage.setScene(start);
		this.primaryStage.show();
	}
	
	
	public void createStartScreen() {
		BorderPane pane = new BorderPane();
		Text title = new Text("Welcome to Baccarat Game");
		Text inst = new Text("To play, enter the port number and IP address you'd like to connect to.");
		TextField enterPort = new TextField();
		TextField enterIP = new TextField();
		Button connect = new Button("connect");
		connect.setOnAction(e->{serverPort = Integer.parseInt(enterPort.getText());
								serverIP = enterIP.getText();
								System.out.println(serverPort);
								System.out.println(serverIP);
								
								Text t = new Text("Connecting...");
								pane.setBottom(t);
								PauseTransition pause =new PauseTransition(Duration.seconds(2));
								pause.play();
								
								//create player thread
								player = new Client(game->{}, serverPort, serverIP);
								player.start();
								
								//create game scene
								createGameScene();
								primaryStage.setScene(gameScene);
		});
		
		pane.setTop(title);
		pane.setCenter(new VBox(50, inst, enterPort, enterIP));
		pane.setRight(connect);
		
		start = new Scene(pane, 600, 600);
	}
	
	
	public void createGameScene() {
		BorderPane pane = new BorderPane();
		
		//left: player's hand
		Rectangle pc1 = new Rectangle(80, 150, Color.DARKSEAGREEN);
		Rectangle pc2 = new Rectangle(80, 150, Color.DARKSEAGREEN);
		Text playerHand = new Text("Player's Hand");
		VBox pVbox = new VBox(15, playerHand, new HBox(15, pc1, pc2));
		pane.setLeft(pVbox);
		
		//right: banker's hand
		Rectangle bc1= new Rectangle(80, 150, Color.DARKSEAGREEN);
		Rectangle bc2 = new Rectangle(80, 150, Color.DARKSEAGREEN);
		Text bankerHand = new Text("Banker's Hand");
		VBox bVbox = new VBox(15, bankerHand, new HBox(15, bc1, bc2));
		pane.setRight(bVbox);
		
		//bottom: enter bid
		TextField enterBid = new TextField("Enter your bid");
		Button bidPlayer = new Button("Player");
		bidPlayer.setOnAction(e->{player.bid.setBid(Integer.parseInt(enterBid.getText()), 1);
								  player.sendBid();	//send to server
		});
		Button bidTie = new Button("Tie");
		bidTie.setOnAction(e->{player.bid.setBid(Integer.parseInt(enterBid.getText()), 2);
							   player.sendBid();	//send bid to server
		});
		Button bidBanker = new Button("Banker");
		bidBanker.setOnAction(e->{player.bid.setBid(Integer.parseInt(enterBid.getText()), 3);
								  player.sendBid();	//send bid to server
		});
		
		//win display
		HBox buttonsVbox = new HBox(20, bidPlayer, bidTie, bidBanker);
		pane.setBottom(new VBox(15, enterBid, buttonsVbox));
		
		//center 
		Text title = new Text("Baccarat");
		Text display = new Text("To start playing, enter your bid");
		Button deal = new Button("Deal card");
		pane.setCenter(new VBox(15, title, display, deal));
		
		
		gameScene = new Scene(pane, 600, 600);
		
	}
	
};
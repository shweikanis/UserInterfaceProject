import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Server {
	
	private int numPlayers = 0;
	ArrayList<ClientThread> players;
	private Consumer<Serializable> changeSceneCall;
	private Consumer<Serializable> addClientInfoCall;
	ListeningThread server;

	
	
	Server(Consumer<Serializable> call, Consumer<Serializable> call2, int port) {
		
		changeSceneCall = call;
		addClientInfoCall = call2;
		server = new ListeningThread(port);
		server.start();
	}
	
	
	//server thread for listening for clients request to connect
	public class ListeningThread extends Thread {
		
		int port;
		
		ListeningThread(int p) {
			port = p;
		}
		
		public void run() {
			
			try(ServerSocket socket = new ServerSocket(port);) {
			    System.out.println("Server is waiting for a client!");

			    
			   while (true) {
				   ClientThread c = new ClientThread(socket.accept(), ++numPlayers);
				// let server screen of new player connected
				   if (numPlayers == 1) {
					   changeSceneCall.accept("new player");
				   } else {
					   addClientInfoCall.accept("new player");
				   }
				   
				   //players.add(c); //idk why it cause problem
				   c.start();
				   System.out.println(numPlayers);

			   }
	
			} catch(Exception e) {
				System.out.println("error");
				e.printStackTrace();
			}	//do i have to add a catch block?
	
		} //end of run
		
	} //end of ListeningThread
	
	
	
	//*should i move client thread to a new class file?

	
	//for each connection create a client thread to manage that client's game session
	public class ClientThread extends Thread {
		
		int playerNum;
		Socket connection;
		ObjectInputStream in;
		ObjectOutputStream out;
		Bid currentBid = new Bid();
		BaccaratGame game;
		
		
		ClientThread(Socket s, int num){
			
			connection = s;
			playerNum = num;	
			
			//open this clients socket's input and output streams
			try {
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);	
			}
			catch(Exception e) {
				System.out.println("Streams not open");
			}	
				
		} //end of constructor
		
		
		public void run() {
			
			while(true) {
				
				try {
					//read in initial data from client : initial bid and who
					currentBid = (Bid)in.readObject();
					System.out.println(currentBid.amount+" "+currentBid.who);
					
					//create instance of BaccaratGame
					game = new BaccaratGame();
					//play hand and send client :
					//initial player and banker hand
					//if either gets and extra card, which one
					//result of game based on client bet, won or lost, how much or tie
					//wait if clients wants another game: receive bet and who again
					
				} catch (Exception e) {
					e.printStackTrace();
					break;
				}
				
				
			} //end of while			
			
		} //end of run
		
	} //end of ClientThread
	
	
	//utility functions
	int getNumPlayers() {
		return numPlayers;
	}
	
	
}

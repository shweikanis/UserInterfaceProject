import java.util.ArrayList;


//This class contains the important information for one game.

public class BaccaratGame {
	
	ArrayList<Card> playerHand;
	ArrayList<Card> bankerHand;
	
	Double currentBet;
	Double totalWinning;
	
	BaccaratDealer theDealer;
	
	//public double evaluateWinnings() {}
	
}

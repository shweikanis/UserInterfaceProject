import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

//Application thread that control the server UI
public class InitServer extends Application {
	
	Scene welcome;
	Scene waiting;
	Scene unavailable;
	Scene clientsInfo;
	
	int listeningPort;
	Server server;
	
	//changing UI widgets
	ListView<Bid> listClients;
	TextField clientsNum;
	
	Stage primaryStage;
	
	public static void main(String[] args) {
		
		launch(args);
	}
	
	
	public void start(Stage primaryStage) throws Exception {
		
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Baccarat Server");
		welcome = createWelcomeScreen();	
		this.primaryStage.setScene(welcome);
		this.primaryStage.show();
	}
	
	
	private Scene createWelcomeScreen() {
		
		TextField enterPort = new TextField();
		Text title = new Text("Welcome Server!");
		Text inst = new Text("For players to connect, choose what port you'd like to listen from:");
		Button startServer = new Button("Start server");
		
		//when button pressed assigned the number entered to listening port variable
		startServer.setOnAction(e->{listeningPort = Integer.parseInt(enterPort.getText());
								 //System.out.println(listeningPort);
		
		waiting = createWaitingScreen();
		primaryStage.setScene(waiting);
		
		
		//define two instance of Consumer<> and accept()
		server = new Server(game->Platform.runLater(()->{
				changeScene(); }), //first instance of Consumer<>
				data->Platform.runLater(()->{
				addClientInfo((Bid)data); }),	//2nd instance of Consumer<>
				listeningPort);
		});
		
		HBox p = new HBox(enterPort, startServer);
		VBox items = new VBox(50, title, inst, p);
		
		return new Scene(items, 600, 600);
	}
	
	
	private void addClientInfo(Bid data) {
		listClients.getItems().add((Bid) data);	//add new client to listview
		clientsNum.setText(String.valueOf(server.getNumPlayers()));	//update the players number display
		
	}
	
	
	private void changeScene() {
		//new player connection, change scene
		clientsInfo = createClientsInfoScreen();
		primaryStage.setScene(clientsInfo);
	}
	
	
	private Scene createClientsInfoScreen() {
		
		BorderPane pane = new BorderPane();
		TextField p = new TextField("Players connected: ");
		clientsNum = new TextField(String.valueOf(server.getNumPlayers()));
		listClients = new ListView<Bid>();
		
		pane.setTop(new HBox(p,clientsNum));
		pane.setCenter(listClients);
		
		return new Scene(pane, 600, 600);
	}
	
	
	private Scene createWaitingScreen() {
		
		BorderPane pane = new BorderPane();
		Text t = new Text("Ready to play\nWaiting for players to connect...");
		// add on and off buttons
		pane.setCenter(t);
		
		return new Scene(pane, 600, 600);
	}
	
}
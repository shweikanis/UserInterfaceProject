import java.io.Serializable;

public class Bid implements Serializable {
	
		int amount;
		int who;	//1 for player, 2 for tie, 3 for banker
		private static final long serialVersionUID = 1L;

		public void setBid(int a, int w) {
			this.amount = a;
			this.who = w;
		}

}

public class Card {
	private String suit;
	private String rank;
	private int value;
	
	Card(String suit, String rank) {
		this.suit = suit;
		this.rank = rank;
	}
	
	
	public String getSuit() {
		return suit;
	}
	
	public String getRank() {
		return rank;
	}
	
	public int getVal() {
		return value;
	}
	
	public void setCardValue() {
		
		if(rank == "Ace") {
				
			value = 1;
		} else if(rank == "10" || rank == "Jack" || rank == "Queen" || rank == "King") {
				
			value = 0;
		} else {
				
			value  = Integer.parseInt(rank);
		}		
	}
	
}

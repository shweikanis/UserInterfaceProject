import java.util.ArrayList;

public class BaccaratGameLogic {

	//public static String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2) { }
	
	public static int handTotal(ArrayList<Card> hand) {
		
		int total = 0;
		
		for(Card c : hand) {
			total += c.getVal();
		}
		
		return total;
	}
	
	//public static boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) { }
	
	//public static boolean evaluatePlayerDraw(ArrayList<Card> hand) { }
	
	
}
	

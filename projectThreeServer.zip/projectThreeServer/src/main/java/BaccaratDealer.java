import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

//Actions that the server/dealer must perform in the game related to the deck of cards
public class BaccaratDealer {
	
	private static final String [] SUIT = {"Clubs", "Diamonds", "Hearts",  "Spades"};
	private static final String [] RANK = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
	private static final int numSuits = 4;
	private static final int numRanks = 13;
	
	private ArrayList<Card> deck;
	
	
	public void generateDeck() {
        
        deck = new ArrayList<Card>();
        
        for (int i = 0; i < numSuits; ++i) {
            for (int j = 0; j < numRanks; ++j) {
            	
            	Card c = new Card(SUIT[i], RANK[j]);
                deck.add(c);
            } 
        }
	}
	
	
	//returns an array with two random cards
	public ArrayList<Card> dealHand() {
		
		int rand1 = ThreadLocalRandom.current().nextInt(0, (deckSize()-1) + 1);
		Card card1 = deck.remove(rand1);
		card1.setCardValue();
		
		int rand2 = ThreadLocalRandom.current().nextInt(0, (deckSize()-1) + 1);
		Card card2 = deck.remove(rand2);
		card2.setCardValue();
		
		ArrayList<Card> hand = new ArrayList<Card>();
		hand.add(card1);
		hand.add(card2);
		
		return hand;
	}
	
	
	//remove and return last card in deck
	public Card drawOne() { 
		Card c = deck.remove(deckSize()-1);
		c.setCardValue();
		return c;	
	}
	
	
	public void shuffleDeck() {
		
		int max = deckSize();
		
		for(int i = 0 ; i < max ; ++i) {
			
			int rand = ThreadLocalRandom.current().nextInt(0, max + 1);
			
			if (rand != i && rand < max && rand >= 0) {
				Card temp = deck.get(i);
				deck.set(i,  deck.get(rand));
				deck.set(rand, temp);
			}	
		} //end of for loop
	}
	
	
	public int deckSize() {
		return deck.size();
	}
	
	
	public void printDeck() {
		for(Card c : deck) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
	}
	
	
	public ArrayList<Card> getDeck() {
		return deck;
	}
	
	
}

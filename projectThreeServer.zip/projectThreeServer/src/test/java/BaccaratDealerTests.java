import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class BaccaratDealerTests {
	
	private static final String [] SUIT = {"Clubs", "Diamonds", "Hearts",  "Spades"};
	private static final String [] RANK = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
	private static final int numSuits = 4;
	private static final int numRanks = 13;
	private static BaccaratDealer dealer;
	

	@BeforeAll
	static void setUp() {
		dealer = new BaccaratDealer();
	}
	
	@BeforeEach
	void init() {
		dealer.generateDeck();
	}
	
	
	@Test
	void generateDeckTest() {
		
		ArrayList<Card> deck = dealer.getDeck();
		assertEquals(52, dealer.deckSize(), "Incorrect number of generated cards");
		
		int k = 0;
		for (int i = 0; i < numSuits; ++i) {
            for (int j = 0; j < numRanks; ++j) {
 
            	Card c = deck.get(k);
            	assertEquals(c.getSuit(), SUIT[i], "Incorrect suit");
            	assertEquals(c.getRank(), RANK[j], "Incorrect value");
//            	System.out.println(c.getSuite() + " " + c.getRank());
            	++k;
            } 
        }	
	}
	
	
	@Test
	void shuffleTest() {
		
		dealer.shuffleDeck();
//		dealer.printDeck();
		assertEquals(52, dealer.deckSize(), "Incorrect deck size after shuffling");
	}

	
	@Test
	void dealHandTest() {
		
		dealer.shuffleDeck();
		
		ArrayList<Card> hand1 = dealer.dealHand();
		for(Card c : hand1) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
		assertEquals(50, dealer.deckSize());
		
		ArrayList<Card> hand2 = dealer.dealHand();
		for(Card c : hand2) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
		assertEquals(48, dealer.deckSize());
		
		ArrayList<Card> hand3 = dealer.dealHand();
		for(Card c : hand3) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
		assertEquals(46, dealer.deckSize());
	}
	
	
	@Test
	void drawOneTest() {
		Card c1 = dealer.drawOne();
		assertEquals("Spades", c1.getSuit(), "One card drawn incorrectly: wrong suit");
		assertEquals("Ace", c1.getRank(), "One card drawn incorrectly: wrong value");
		assertEquals(51, dealer.deckSize(), "Drawn card not removed from deck");
		
		Card c2 = dealer.drawOne();
		assertEquals("Spades", c2.getSuit(), "One card drawn incorrectly: wrong suit");
		assertEquals("King", c2.getRank(), "One card drawn incorrectly: wrong value");
		assertEquals(50, dealer.deckSize(), "Drawn card not removed from deck");
	}	
	
}

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;


public class ServerTests {
	
	static InitServer initServer;
	
	@BeforeEach
	void init() {
		
		initServer = new InitServer();
	}
	
//	@BeforeAll
//	static void setUp() {
//		
//	}


}

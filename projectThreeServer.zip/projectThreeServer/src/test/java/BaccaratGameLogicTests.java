import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class BaccaratGameLogicTests {

	private static ArrayList<Card> playerHand;
	private static ArrayList<Card> bankerHand;
	private static BaccaratDealer dealer;
	private static int playerTotal;
	private static int bankerTotal;
	
	@BeforeAll
	static void setUp() {
		dealer = new BaccaratDealer();
		dealer.generateDeck();
		dealer.shuffleDeck();
		playerHand = dealer.dealHand();
		bankerHand = dealer.dealHand();
		playerTotal = 0;
		bankerTotal = 0;
	}
	
	
	@Test
	void handTotalTests() {
		
		for(Card c : playerHand) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
		playerTotal += playerHand.get(0).getVal();
		playerTotal += playerHand.get(1).getVal();
		assertEquals(playerTotal, BaccaratGameLogic.handTotal(playerHand), "Incorrect player hand total");
		System.out.println("total: " + playerTotal);
		
		for(Card c : bankerHand) {
			System.out.println(c.getSuit() + " " + c.getRank());
		}
		bankerTotal += bankerHand.get(0).getVal();
		bankerTotal += bankerHand.get(1).getVal();
		assertEquals(bankerTotal, BaccaratGameLogic.handTotal(bankerHand), "Incorrect banker hand total");
		System.out.println("total: " + bankerTotal);
	}
	
	
}
